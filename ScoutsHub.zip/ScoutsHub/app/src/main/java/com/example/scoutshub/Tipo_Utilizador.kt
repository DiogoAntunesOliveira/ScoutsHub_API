package com.example.scoutshub

import org.json.JSONObject

class Tipo_Utilizador {

    var id_tipo : Int? = null
    var designacao : String? = null

    constructor(id_tipo: Int?, designacao: String?) {
        this.id_tipo = id_tipo
        this.designacao = designacao
    }

    fun toJson() : JSONObject {
        val jsonObject = JSONObject()

        jsonObject.put("id_tipo", id_tipo)
        jsonObject.put("designacao", designacao)

        return jsonObject
    }

    companion object {

        fun fromJson(jsonObject: JSONObject) : Tipo_Utilizador {
            val tipo_utilizador = Tipo_Utilizador()
            tipo_utilizador.id_tipo = jsonObject.getInt("id_tipo")
            tipo_utilizador.designacao = jsonObject.getString("designacao")

            return tipo_utilizador
        }

    }

    constructor()
}